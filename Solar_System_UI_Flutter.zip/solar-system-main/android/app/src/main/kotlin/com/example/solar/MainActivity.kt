package com.example.solar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
