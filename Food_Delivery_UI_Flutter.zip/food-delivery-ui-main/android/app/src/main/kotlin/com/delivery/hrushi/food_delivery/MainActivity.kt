package com.delivery.hrushi.food_delivery

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
