﻿import 'package:flutter/widgets.dart';

Color lightPink = const Color(0xFFFFE3D9);
